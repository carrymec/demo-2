<template>
  <div class="">
    product
  </div>
</template>

<script>


  // 传递给子组件的值
  export default {
    data () {
      return {}
    },
    methods: {

    }
  }
</script>
<style>

</style>
